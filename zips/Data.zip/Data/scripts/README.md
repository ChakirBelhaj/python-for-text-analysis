# Scripts

This folder contains the scripts I used to get the data for this course.
Feel free to look through them :)
