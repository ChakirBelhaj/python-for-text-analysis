# Sentiment scores from Dodds et al. 2014

The data in this directory, sentiment scores for 100,000 words across 10 languages,
were downloaded from [here](http://www.uvm.edu/storylab/share/papers/dodds2014a/data.html).
The authors describe their collection procedure as follows:

> We then paid native speakers to rate how they felt in response to individual
> words on a 9 point scale, with 1 corresponding to most negative or saddest, 5
> to neutral, and 9 to most positive or happiest 
